using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ClienteDb.Data;
using ClienteDb.Models;
using Microsoft.Extensions.Logging;

namespace ClienteDb.Controllers
{
    public class ClientesController : Controller
    {
        // gestiona la conexión a la base de datos y de proporcionar acceso a las tablas y entidades a través de propiedades DbSet.
        private readonly ApplicationDbContext _context;
        //permite registrar información, advertencias, errores u otros eventos importantes durante la ejecución del código en el controlador.
        private readonly ILogger<ClientesController> _logger;


// constructor para context y logger 
        public ClientesController(ApplicationDbContext context, ILogger<ClientesController> logger)
        {
            _context = context;
            _logger = logger;
        }

        // GET: Clientes 
        //Devuelve un IActionResult, que es un resultado de una acción de MVC 

        public async Task<IActionResult> Index()
        {
            try
            {
                /*Utiliza el contexto de la base de datos _context para obtener todos los registros de clientes 
                desde la tabla Clientes y los almacena en la variable clientes*/
                //Se usa await para permitirle al programa obtener todos los datos sin que se caiga
                //to ListAsync() es una funcion de entity framewrok que permite obtener los datos
                var clientes = await _context.Clientes.ToListAsync();
                // en caso de que clientes este vacio o alguna entrada sea null
                if (clientes == null || !clientes.Any())
                {
                    _logger.LogWarning("Error al intentar mostrar clientes");
                }
                return View(clientes);
            }
            //captura cualquier excepción del tipo Exception. Capturar Exception
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ha ocurrisdo un error.");
                return View(new List<Cliente>()); 
            }
        }

        // GET: Clientes/Create
        // Retorna la vista asociada a la acción Create.
        public IActionResult Create()
        {
            return View();
        }

        // POST: Clientes/Create
        [HttpPost] //  indica que el método maneja solicitudes HTTP POST. 

        //método POST Create, que recibe los datos del formulario de creación de clientes como parámetro.
        public async Task<IActionResult> Create([Bind("Nombre,Telefono,FechaNacimiento,Estado,Saldo")] Cliente cliente)

        //Atributo utilizado para especificar qué propiedades del
        // modelo Cliente se deben vincular desde la solicitud HTTP a las propiedades del objeto cliente
        {
            if (ModelState.IsValid)
            //verifica que lo que se paso desde la vista sea valido, si es asi procede a anadirlo
            {
                _context.Add(cliente);
                await _context.SaveChangesAsync(); // actuliza los cambios 
                return RedirectToAction(nameof(Index)); // vuelve al inicio 
            }
            return View(cliente);
        }

        // GET: Clientes/Delete/5

        // ? indica que puede ser nullo el id, si es nulo, se manejan las excepciones
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                _logger.LogWarning("No hay datos para ser eliminados");
                return NotFound();
            }

            var cliente = await _context.Clientes
                .FirstOrDefaultAsync(m => m.Cedula == id); // Devuelve el primer 
                //elemento que cumple con la condición especificada, o null si no se encuentra ningún elemento.
                // lambda => para ponerlo en la misma linea y el asignar m.cedula con el valor de Id 
            if (cliente == null)
            {
                _logger.LogWarning($"No chay clientes con el id  {id}.");
                return NotFound();
            }

            return View(cliente);
        }

        // POST: Clientes/Delete/5
        [HttpPost, ActionName("Delete")]
     
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var cliente = await _context.Clientes.FindAsync(id);
            if (cliente == null)
            {
                _logger.LogWarning($"No hay clientes con el id  {id} ");
                return NotFound();
            }
            // si encuentra al cliente, lo remueve y despues actualiza
            _context.Clientes.Remove(cliente);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ClienteExists(int id)
        {
            return _context.Clientes.Any(e => e.Cedula == id);
        }
    }
}



