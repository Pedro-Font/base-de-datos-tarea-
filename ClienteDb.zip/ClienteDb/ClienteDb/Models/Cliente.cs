using System;
using System.ComponentModel.DataAnnotations;

namespace ClienteDb.Models
{
    // Define la clase Cliente
    public class Cliente
    {
        // Propiedad Cedula, que actúa como clave primaria en la base de datos
        [Key]
        public int Cedula { get; set; }

        // Propiedad Nombre, que debe tener una longitud máxima de 50 caracteres y es requerida
        [StringLength(50)]
        [Required]
        public string Nombre { get; set; } = string.Empty;

        // Propiedad Telefono, que debe tener una longitud máxima de 8 caracteres y es requerida
        [StringLength(8)]
        [Required]
        public string Telefono { get; set; } = string.Empty;

        // Propiedad FechaNacimiento, que puede ser nula (nullable) y representa la fecha de nacimiento del cliente
        public DateTime? FechaNacimiento { get; set; }

        // Propiedad Estado, que representa el estado del cliente (activo/inactivo, por ejemplo)
        public bool Estado { get; set; } = true;

        // Propiedad Saldo, que representa el saldo del cliente y tiene un valor predeterminado de 0
        public double Saldo { get; set; } = 0;
    }
}



