using Microsoft.EntityFrameworkCore;
using ClienteDb.Models;

namespace ClienteDb.Data
{
    // Define la clase ApplicationDbContext que hereda de DbContext
    public class ApplicationDbContext : DbContext
    {
        // Constructor 
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) 
        // Llama al constructor base de DbContext con las opciones proporcionadas
        {
        }

        // DbSet que representa la tabla de Clientes en la base de datos
        public DbSet<Cliente> Clientes { get; set; }
    }
}


